#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_button10_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_medecin_activate_default            (GtkWindow       *window,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button14adh_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15adh_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_admin_set_focus                     (GtkWindow       *window,
                                        GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimer_as_admin_clicked          (GtkWidget         *objet_graphique,
                                        gpointer         user_data);

void
on_modifier_as_admin_clicked           (GtkWidget         *objet_graphique,
                                        gpointer         user_data);


gboolean
on_notebook1_select_page               (GtkNotebook     *notebook,
                                        gboolean         move_focus,
                                        gpointer         user_data);


void
on_affichetree_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_ajouter_admin_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_adherent_set_focus                  (GtkWindow       *window,
                                        GtkWidget       *widget,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button19_leave                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button26_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_afiiiiiiiiiichageadhhhh_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button31_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_medecin_set_focus                   (GtkWidget      *objet_graphique,
                                        GtkWidget       *widget,
                                        gpointer         user_data);

void
on_coach_set_focus                     (GtkWidget      *objet_graphique,
                                        GtkWidget       *widget,
                                        gpointer         user_data);

void
on_dietecien_set_focus                 (GtkWidget      *objet_graphique,
                                        GtkWidget       *widget,
                                        gpointer         user_data);

void
on_kine_set_focus                      (GtkWidget      *objet_graphique,
                                        GtkWidget       *widget,
                                        gpointer         user_data);

void
on_valider_nouveau_compt_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_as_admin_staff_clicked    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button35_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button37_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button40_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_fiche_set_focus                     (GtkWidget      *objet_graphique,
                                        GtkWidget       *widget,
                                        gpointer         user_data);

void
on_button45_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button44_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button47_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button46_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button42_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button43_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_as_adm_coach_staff_clicked (GtkWidget         *objet_graphique,
                                        gpointer         user_data);

void
on_button36_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button49_clicked                    (GtkWidget         *objet_graphique,
                                        gpointer         user_data);

void
on_button55_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button53_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button58_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button51_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button59_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button60_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button61_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
