void affichage_fenetre(char cin,char date[] ,char prenom[] ,char username[],char mail[] ,char abonnement[] ,char telephone[]);
