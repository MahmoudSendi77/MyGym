int verifier(char login[],char password[]);
void valider_compts(char login[],char password[],int role);

void creer_fiche_medicale(long *cin , char nom[], char prenom[],int *taille,int *poids,char antecedant[]);
void creer_evennement(long cin,char nom[], char lieu[], char heure[],int dej,int dem,int dea);
void creer_rendez_vous(long cin2,int dej,int dem,int dea, char heure[],long cin);
