#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include<math.h>
#include<gdk-pixbuf/gdk-pixbuf.h>
#include <gtk/gtk.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "ajout.h"
#include "verifier.h"
#include "affichage.h"
#include"afichage_fenetre.h"



GtkWidget  *test;

GtkWidget *authentification,*home;
void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
home=lookup_widget(objet_graphique,"home");
authentification=create_authentification();
gtk_widget_show(authentification);

}


GtkWidget *signin,*home;

void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
home=lookup_widget(objet_graphique,"home");
signin=create_signin();
gtk_widget_show(signin);
}


GtkWidget *authentification,*textview1,*textview2,*home,*admin,*medecin,*error,*kine,*adherent,*coach,*dietecien,*label35,*label36;
void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f;
int role;
char login[30];
char password[30];
long cin23;
char username20[30];
char cin20[30];
char prenom20[30];
char password20[30];
char date20[30];
char date21[30];
char mail20[30];
char compt20[30];
char abonnement20[30];
char telephone20[30];
long telephone21;
int ddj20,dda20,ddm20,dfa20,dfm20,dfj20,rolx20;
char date[30],prenom[30],mail[30],username[30],telephone[30],abonnement[30];


int c;
GtkWidget *output40;
GtkWidget *output41;
GtkWidget *output30;
GtkWidget *output31;

GtkWidget *input1,*input2;
GtkWidget *output410;
GtkWidget *output411;
GtkWidget *output412;
GtkWidget *output413;
GtkWidget *output414;
GtkWidget *output415;
GtkWidget *output416;



input1=lookup_widget(objet_graphique,"entry1");
input2=lookup_widget(objet_graphique,"entry2");
authentification=lookup_widget(objet_graphique,"authentification");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));
c=verifier(login,password);
logs_set(login,c);
if (c==1)
{admin=create_admin();
gtk_widget_show(admin);
gtk_widget_hide(authentification);

}
else if (c==2)
{medecin=create_medecin();
gtk_widget_show(medecin);
gtk_widget_hide(authentification);
}
else if (c==3)
{dietecien=create_dietecien();
gtk_widget_show(dietecien);
gtk_widget_hide(authentification);}
else if (c==4)
{coach=create_coach();
gtk_widget_show(coach);
gtk_widget_hide(authentification);
}
else if (c==5)
{kine=create_kine();
gtk_widget_show(kine);
gtk_widget_hide(authentification);}
else if (c==6)
{adherent=create_adherent();
gtk_widget_show(adherent);
gtk_widget_hide(authentification);

}

else if (c==-1)
{error=create_error();
gtk_widget_show(error);
gtk_widget_hide(authentification);}
}

GtkWidget *signin;
void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{/*
GtkWidget *input3,*input4,*input5;
char login1[30],password1[30],rolec[10];
int role;

input3=lookup_widget(objet_graphique,"entry3");
input4=lookup_widget(objet_graphique,"entry4");
input5=lookup_widget(objet_graphique,"entry5");

signin=lookup_widget(objet_graphique,"signin");

strcpy(login1,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(password1,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(rolec,gtk_entry_get_text(GTK_ENTRY(input5)));
role=atoi(rolec);
ajouter(login1,password1,role);
gtk_widget_hide(signin);
*/
}



GtkWidget *signin,*error;
void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
error=lookup_widget(objet_graphique,"error");
signin=create_signin();
gtk_widget_show(signin);
gtk_widget_hide(error);

}


GtkWidget *authentification,*error;

void
on_button10_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
error=lookup_widget(objet_graphique,"error");
authentification=create_authentification();
gtk_widget_show(authentification);
gtk_widget_hide(error);
}


void
on_medecin_activate_default            (GtkWindow       *window,
                                        gpointer         user_data)
{

}

GtkWidget *admin;
void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *combobox4;
GtkWidget *combobox3;


GtkWidget *dnj,*dnm,*dna,*dda,*ddm,*ddj,*dfa,*dfm,*label90,*dfj,*input101,*input100,*tel1,*cin1,*prenom,*password2;

long cin2;
char username1[30];
char prenom1[30];
char password11[30];
char nom1[30];
char cin9[30];
char mail1[30];
char compt[30];
char abonnement1[30];
long telephone1;
int ddj1,dda1,ddm1,dfa1,dfm1,dfj1,dna1,dnj1,dnm1;

int rolx;
input100=lookup_widget(objet_graphique,"entry6");
prenom=lookup_widget(objet_graphique,"entry105");
password2=lookup_widget(objet_graphique,"entry106");
input101=lookup_widget(objet_graphique,"entry7");
label90=lookup_widget(objet_graphique,"label90");
cin1=lookup_widget(objet_graphique,"spinbutton15");


tel1=lookup_widget(objet_graphique,"spinbutton16");

dnj=lookup_widget(objet_graphique,"spinbutton66");
dnm=lookup_widget(objet_graphique,"spinbutton67");
dna=lookup_widget(objet_graphique,"spinbutton68");

ddj=lookup_widget(objet_graphique,"spinbutton9");
ddm=lookup_widget(objet_graphique,"spinbutton10");
dda=lookup_widget(objet_graphique,"spinbutton11");


dfj=lookup_widget(objet_graphique,"spinbutton12");
dfm=lookup_widget(objet_graphique,"spinbutton14");
dfa=lookup_widget(objet_graphique,"spinbutton13");

combobox3=lookup_widget(objet_graphique,"combobox3");
combobox4=lookup_widget(objet_graphique,"combobox4");


admin=lookup_widget(objet_graphique,"admin");

strcpy(username1,gtk_entry_get_text(GTK_ENTRY(input100)));
strcpy(prenom1,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(password11,gtk_entry_get_text(GTK_ENTRY(password2)));

strcpy(mail1,gtk_entry_get_text(GTK_ENTRY(input101)));
cin2=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cin1));

telephone1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(tel1));


dnj1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dnj));
dnm1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dnm));
dna1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dna));


ddj1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ddj));
ddm1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ddm));
dda1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dda));

dfj1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dfj));
dfm1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dfm));
dfa1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dfa));

strcpy(abonnement1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)));
strcpy(compt,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox4)));


if(strcmp(compt,"adherent")==0){
rolx=6;
}
else if(strcmp(compt,"admin")==0){
rolx=1;
}
else if(strcmp(compt,"coach")==0){
rolx=4;
}
else if(strcmp(compt,"dietecien")==0){
rolx=3;
strcpy(abonnement1,"dietecien");
}
else if(strcmp(compt,"kine")==0){
rolx=5;
strcpy(abonnement1,"kine");
}
else if(strcmp(compt,"medecin")==0){
rolx=2;
strcpy(abonnement1,"medecin");
}

if(rolx==6){
printf("\ndfdfdfdfdfdf\n");
ajouter(cin2,password11,rolx,username1,prenom1,mail1,abonnement1,telephone1,ddj1,ddm1,dda1,dfj1,dfm1,dfa1,dnj1,dnm1,dna1);
}
else if(rolx!=6){
ajouter_staff_coach(cin2,password11,username1,prenom1,mail1,compt,abonnement1,telephone1,dnj1,dnm1,dna1);
}
sprintf(cin9,"%ld",cin2);
valider_compts(cin9,password11,rolx);

gtk_label_set_text(GTK_LABEL(label90),"inscription réusite.");

}

GtkWidget *admin,*home;
void
on_admin_set_focus                     (GtkWindow       *window,
                                        GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview2,treeview3;
GtkWidget *admin;

admin=lookup_widget(window,"admin");
//gtk_widget_destroy(home);

treeview2=lookup_widget(admin,"treeview1");
//treeview3=lookup_widget(admin,"treeview3");

afficher_adherent(treeview2);
//afficher_staff_coach(treeview3);
	
}



void
on_button14adh_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}

GtkWidget *adherent;
void
on_button15adh_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom_event,*lieu_event,*heure_event,*dej,*dem,*dea,*cin,*cin2;

printf("sssssssssssssssssssssssssssssss888799po888888888888sssssssssssss\n");

int dej1,dem1,dea1,cin1,cin3;
char nom_event1[30],lieu_event1[30],heure_event1[30];

adherent=lookup_widget(objet_graphique,"adherent");

heure_event=lookup_widget(objet_graphique,"entry158");

dej=lookup_widget(objet_graphique,"spinbutton20");
dem=lookup_widget(objet_graphique,"spinbutton21");
dea=lookup_widget(objet_graphique,"spinbutton22");
cin=lookup_widget(objet_graphique,"spinbutton85");
cin2=lookup_widget(objet_graphique,"spinbutton86");


strcpy(heure_event1,gtk_entry_get_text(GTK_ENTRY(heure_event)));

cin3=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cin2));
dej1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dej));
dem1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dem));
dea1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dea));

cin1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cin));
printf("sssssssssssssssssssssssssssssss888888888888888sssssssssssss\n");
creer_rendez_vous(cin3,dej1,dem1,dea1,heure_event1,cin1);
printf("ssssssssssssssssssssssssssssssssss777777ssssssssss\n");

}



GtkWidget *admin;
void
on_supprimer_as_admin_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *supprimeraz;
int cin;
admin=lookup_widget(objet_graphique,"admin");
supprimeraz=lookup_widget(objet_graphique,"spinbutton65");
cin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(supprimeraz));
supprimer(cin);
}

GtkWidget *admin,*window2;
void
on_modifier_as_admin_clicked           (GtkWidget         *objet_graphique,
                                        gpointer         user_data)
{



GtkWidget *output410;
GtkWidget *output411;
GtkWidget *output412;
GtkWidget *output413;
char mail[30],abonnement[30];
long cin,telephone;

FILE *f;
long cin5;
char username5[30];
char password5[30];
char prenom5[30];
char nom5[30];
char mail5[30];
char compt5[30];
char abonnement5[30];
long telephone5;
int ddj5,dda5,ddm5,dfa5,dfm5,dfj5,dna5,dnm5,dnj5,m=0,rolx5;

char username1[30];
char password1[30];
char prenom1[30];
char nom1[30];
char mail1[30];
char compt1[30];
char abonnement1[30];
long telephone1;
int ddj1,dda1,ddm1,dfa1,dfm1,dfj1,dna1,dnm1,dnj1,rolx1;

admin=lookup_widget(objet_graphique,"admin");
output410=lookup_widget(objet_graphique,"spinbutton65");
output411=lookup_widget(objet_graphique,"spinbutton79");


output412=lookup_widget(objet_graphique,"entry155");
output413=lookup_widget(objet_graphique,"entry157");

cin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output410));
telephone=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output411));


strcpy(mail,gtk_entry_get_text(GTK_ENTRY(output412)));
strcpy(abonnement,gtk_entry_get_text(GTK_ENTRY(output413)));
f=fopen("/home/jasser/Desktop/MyGym/gym/src/info_users.txt","r");
if(f!=NULL){
while(fscanf(f,"%ld %s %d %s %s %s %s %ld %d %d %d %d %d %d %d %d %d ",&cin5, password5,&rolx5,username5,mail5, prenom5,abonnement5,&telephone5,&ddj5,&ddm5,&dda5,&dfj5,&dfm5,&dfa5,&dnj5,&dnm5,&dna5)!=EOF)
{
if(cin==cin5){
dna1=dna5;
dnm1=dnm5;
dnj1=dnj5;

dfa1=dfa5;
dfm1=dfm5;
dfj1=dfj5;

dda1=dda5;
ddm1=ddm5;
ddj1=ddj5;

strcpy(prenom1,prenom5);
strcpy(username1,username5);
rolx1=rolx5;
strcpy(password1,password5);

}
}
}
fclose(f);
supprimer(cin);
ajouter(cin,password1,rolx1,prenom1,username1,mail,abonnement,telephone,ddj1,ddm1,dda1,dfj1,dfm1,dfa1,dnj1,dnm1,dna1);


//supprimer(cin);

//window2=create_window2();
//gtk_widget_show(window2);


}



gboolean
on_notebook1_select_page               (GtkNotebook     *notebook,
                                        gboolean         move_focus,
                                        gpointer         user_data)
{
/*
GtkWidget *treeview2;
GtkWidget *admin;
GtkNotebook     *notebook2;

notebook2=lookup_widget(notebook,"notebook1");
//gtk_widget_destroy(home);

treeview2=lookup_widget(notebook2,"treeview1");


afficher_adherent(treeview2);*/

/*
GtkWidget *treeview1;
GtkWidget *adherent1;

admin=lookup_widget(objet,"admin");

adherent1 = notebook.get_current_page();
gtk_widget_destroy(home);
      
treeview1=lookup_widget(adherent1,"treeview1");

afficher_adherent(treeview1);
  return FALSE;*/
}



void
on_affichetree_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview2;
GtkWidget *admin;

admin=lookup_widget(objet_graphique,"admin");
//gtk_widget_destroy(home);
//test=lookup_widget(objet_graphique,"test");
//test=create_test();
//gtk_widget_show(test);



treeview2=lookup_widget(admin,"treeview3");


afficher_staf_coach(treeview2);

}




void
on_ajouter_admin_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input10000,*input10001;
GtkWidget *admin;
char login[20];char password[20];
int c;

admin=lookup_widget(objet_graphique,"admin");

input10001=lookup_widget(objet_graphique,"entry107");
input10000=lookup_widget(objet_graphique,"entry108");

strcpy(login,gtk_entry_get_text(GTK_ENTRY(input10001)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input10000)));
c=1;
valider_compts(login,password,c);
}

GtkWidget *adherent;
GtkWidget *image30;
void
on_adherent_set_focus                  (GtkWindow       *objet_graphique,
                                        GtkWidget       *widget,
                                        gpointer         user_data)
{
GtkWidget *treeview2;
GtkWidget *adherent;


GtkWidget *output410;
GtkWidget *output411;
GtkWidget *output412;
GtkWidget *output413;
GtkWidget *output414;
GtkWidget *output415;
GtkWidget *output416;

char date[30],prenom[30],mail[30],username[30],telephone[30],login[30],abonnement[30];


FILE *f,*g;
int role;
char imaage[30];
char password[30];
long cin23;
char username20[30];
char cin20[30];
char prenom20[30];
char password20[30];
char date20[30];
char date21[30];
char mail20[30];
char compt20[30];
char abonnement20[30];
char telephone20[30];
long telephone21;

int ddj20,dda20,ddm20,dfa20,dfm20,dfj20,rolx20,dna20,dnm20,dnj20,m;

printf("\n %s \nfffffffffffffffffffff",login);

adherent=lookup_widget(objet_graphique,"adherent");

output410=lookup_widget(objet_graphique,"label588");
output411=lookup_widget(objet_graphique,"label596");
output412=lookup_widget(objet_graphique,"label589");

output413=lookup_widget(objet_graphique,"label590");
output414=lookup_widget(objet_graphique,"label591");
output415=lookup_widget(objet_graphique,"label592");

output416=lookup_widget(objet_graphique,"label593");


g=fopen("/home/jasser/Desktop/MyGym/gym/src/logs.txt","r");
if(g!=NULL){
printf("pos99999999999966666669999\n");
while(fscanf(g,"%s %d",login,&m)!=EOF){

printf("ffffffff\n %s \n",login);
}
}


image30 = create_pixmap(adherent,"12.jpeg");
gtk_widget_show(image30);
  //gtk_fixed_put (GTK_FIXED (fixed14), image30, 536, 24);
  //gtk_widget_set_size_request (image30, 216, 232);
 // gtk_box_pack_start (GTK_BOX (hbox11), image30, TRUE, TRUE, 0);
  //gtk_widget_set_size_request (image30, 320, 420);


f=fopen("/home/jasser/Desktop/MyGym/gym/src/info_users.txt","r");
if(f!=NULL){
printf("pos999999999999********************9999\n");
while(fscanf(f,"%ld %s %d %s %s %s %s %ld %d %d %d %d %d %d %d %d %d ",&cin23,password20,&rolx20,username20,prenom20,mail20,abonnement20,&telephone21,&ddj20,&ddm20,&dda20,&dfj20,&dfm20,&dfa20,&dnj20,&dnm20,&dna20)!=EOF)
{
	
	sprintf(cin20,"%ld",cin23);
if(strcmp(login,cin20)==0)
{
printf("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz55555555555555z");
	sprintf(date20,"%d/%d/%d",ddj20,ddm20,dda20);
	sprintf(date21,"%d/%d/%d",dfj20,dfm20,dfa20);
	sprintf(telephone20,"%ld",telephone21);

strcpy(username,username20);
strcpy(prenom,prenom20);
strcpy(mail,mail20);
strcpy(abonnement,abonnement20);
strcpy(telephone,telephone20);
strcpy(date,date20);
gtk_label_set_text(GTK_LABEL(output410),username);
gtk_label_set_text(GTK_LABEL(output411),prenom);
gtk_label_set_text(GTK_LABEL(output412),login);
gtk_label_set_text(GTK_LABEL(output413),mail);
gtk_label_set_text(GTK_LABEL(output414),telephone);
gtk_label_set_text(GTK_LABEL(output415),date);
gtk_label_set_text(GTK_LABEL(output416),abonnement);
}

}

}
fclose(f);








adherent=lookup_widget(objet_graphique,"adherent");
treeview2=lookup_widget(adherent,"treeview5");


afficher_staf_coach(treeview2);
}

GtkWidget *coach;
void
on_button18_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *nom_event,*lieu_event,*heure_event,*dej,*dem,*dea,*cin;


int dej1,dem1,dea1,cin1;
char nom_event1[30],lieu_event1[30],heure_event1[30];

coach=lookup_widget(objet_graphique,"coach");


nom_event=lookup_widget(objet_graphique,"entry109");
lieu_event=lookup_widget(objet_graphique,"entry147");
heure_event=lookup_widget(objet_graphique,"entry148");

dej=lookup_widget(objet_graphique,"spinbutton27");
dem=lookup_widget(objet_graphique,"spinbutton28");
dea=lookup_widget(objet_graphique,"spinbutton29");
cin=lookup_widget(objet_graphique,"spinbutton87");


strcpy(nom_event1,gtk_entry_get_text(GTK_ENTRY(nom_event)));
strcpy(lieu_event1,gtk_entry_get_text(GTK_ENTRY(lieu_event)));
strcpy(heure_event1,gtk_entry_get_text(GTK_ENTRY(heure_event)));

dej1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dej));
dem1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dem));
dea1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(dea));
cin1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cin));

creer_evennement(cin1,nom_event1,lieu_event1,heure_event1,dej1,dem1,dea1);



}


void
on_button19_leave                      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}

GtkWidget *medecin,*fiche_medicale_adherants;

void
on_button25_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
medecin=lookup_widget(objet_graphique,"medecin");
fiche_medicale_adherants=create_fiche_medicale_adherants();
gtk_widget_show(fiche_medicale_adherants);


}


void
on_button26_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}

GtkWidget *adherent;
void
on_afiiiiiiiiiichageadhhhh_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *output410;
GtkWidget *output411;
GtkWidget *output412;
GtkWidget *output413;
GtkWidget *output414;
GtkWidget *output415;
GtkWidget *output416;
char date[30],prenom[30],mail[30],username[30],telephone[30],login[30],abonnement[30];


FILE *f,*g;
int role;
char password[30];
long cin23;
char username20[30];
char cin20[30];
char prenom20[30];
char password20[30];
char date20[30];
char date21[30];
char mail20[30];
char compt20[30];
char abonnement20[30];
char telephone20[30];
long telephone21;

int ddj20,dda20,ddm20,dfa20,dfm20,dfj20,rolx20,dna20,dnm20,dnj20,m;

printf("\n %s \nfffffffffffffffffffff",login);

adherent=lookup_widget(objet_graphique,"adherent");

output410=lookup_widget(objet_graphique,"label588");
output411=lookup_widget(objet_graphique,"label596");
output412=lookup_widget(objet_graphique,"label589");

output413=lookup_widget(objet_graphique,"label590");
output414=lookup_widget(objet_graphique,"label591");
output415=lookup_widget(objet_graphique,"label592");

output416=lookup_widget(objet_graphique,"label593");


g=fopen("/home/jasser/Desktop/MyGym/gym/src/logs.txt","r");
if(g!=NULL){
printf("pos99999999999966666669999\n");
while(fscanf(g,"%s %d",login,&m)!=EOF){

printf("ffffffff\n %s \n",login);
}
}

f=fopen("/home/jasser/Desktop/MyGym/gym/src/info_users.txt","r");
if(f!=NULL){
printf("pos999999999999********************9999\n");
while(fscanf(f,"%ld %s %d %s %s %s %s %ld %d %d %d %d %d %d %d %d %d ",&cin23,password20,&rolx20,username20,prenom20,mail20,abonnement20,&telephone21,&ddj20,&ddm20,&dda20,&dfj20,&dfm20,&dfa20,&dnj20,&dnm20,&dna20)!=EOF)
{
	
	sprintf(cin20,"%ld",cin23);
if(strcmp(login,cin20)==0)
{
printf("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz55555555555555z");
	sprintf(date20,"%d/%d/%d",ddj20,ddm20,dda20);
	sprintf(date21,"%d/%d/%d",dfj20,dfm20,dfa20);
	sprintf(telephone20,"%ld",telephone21);

strcpy(username,username20);
strcpy(prenom,prenom20);
strcpy(mail,mail20);
strcpy(abonnement,abonnement20);
strcpy(telephone,telephone20);
strcpy(date,date20);
gtk_label_set_text(GTK_LABEL(output410),username);
gtk_label_set_text(GTK_LABEL(output411),prenom);
gtk_label_set_text(GTK_LABEL(output412),login);
gtk_label_set_text(GTK_LABEL(output413),mail);
gtk_label_set_text(GTK_LABEL(output414),telephone);
gtk_label_set_text(GTK_LABEL(output415),date);
gtk_label_set_text(GTK_LABEL(output416),abonnement);
}

}

}
fclose(f);


/*
treeview2=lookup_widget(adherent,"treeview5");


afficher_staf_coach(treeview2);*/



}

GtkWidget *window2;
void
on_button31_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


GtkWidget *admmodif1;
GtkWidget *admmodif2;
GtkWidget *admmodif3;
GtkWidget *admmodif4;
GtkWidget *admmodif5;
GtkWidget *admmodif6;
GtkWidget *admmodif7;
GtkWidget *admmodif8;
GtkWidget *admmodif9;
GtkWidget *admmodif10;
GtkWidget *admmodif11;
GtkWidget *admmodif12;
GtkWidget *admmodif13;
GtkWidget *admmodif14;
GtkWidget *admmodif15;
GtkWidget *admmodif16;
GtkWidget *admmodif17;
GtkWidget *admmodif18;

GtkWidget *expl;

expl=lookup_widget(objet_graphique,"label951");

gtk_label_set_text(GTK_LABEL(expl),"!!!!!!!!!!!!!!!!! mot de pass erronee");

char nom[30],prenom[30],mail[30],specialite[30],compte[30],password[30],password2[30],cin200[30];

long cin,telephone;

int dnj,dnm,dna,ddj,ddm,dda,dfj,dfm,dfa,rolx,c,b,n;

window2=lookup_widget(objet_graphique,"window2");

admmodif1=lookup_widget(objet_graphique,"entry142");
admmodif2=lookup_widget(objet_graphique,"entry143");

admmodif18=lookup_widget(objet_graphique,"entry153");

admmodif9=lookup_widget(objet_graphique,"entry152");

admmodif3=lookup_widget(objet_graphique,"spinbutton63");

admmodif4=lookup_widget(objet_graphique,"spinbutton54");
admmodif5=lookup_widget(objet_graphique,"spinbutton55");
admmodif6=lookup_widget(objet_graphique,"spinbutton56");

admmodif7=lookup_widget(objet_graphique,"spinbutton64");

admmodif8=lookup_widget(objet_graphique,"entry144");

admmodif10=lookup_widget(objet_graphique,"combobox14");

admmodif11=lookup_widget(objet_graphique,"spinbutton57");
admmodif12=lookup_widget(objet_graphique,"spinbutton58");
admmodif13=lookup_widget(objet_graphique,"spinbutton59");

admmodif14=lookup_widget(objet_graphique,"spinbutton60");
admmodif15=lookup_widget(objet_graphique,"spinbutton61");
admmodif16=lookup_widget(objet_graphique,"spinbutton62");

admmodif17=lookup_widget(objet_graphique,"combobox15");

strcpy(nom,gtk_entry_get_text(GTK_ENTRY(admmodif1)));
strcpy(password2,gtk_entry_get_text(GTK_ENTRY(admmodif18)));


strcpy(password,gtk_entry_get_text(GTK_ENTRY(admmodif9)));
strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(admmodif2)));

cin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(admmodif3));

dnj=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(admmodif4));
dnm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(admmodif5));
dna=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(admmodif6));

telephone=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(admmodif7));

strcpy(mail,gtk_entry_get_text(GTK_ENTRY(admmodif8)));

strcpy(specialite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(admmodif10)));

ddj=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(admmodif11));
ddm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(admmodif12));
dda=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(admmodif13));

dfj=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(admmodif14));
dfm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(admmodif15));
dfa=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(admmodif16));

strcpy(compte,gtk_combo_box_get_active_text(GTK_COMBO_BOX(admmodif17)));

sprintf(cin200,"%ld",cin);

c=verifier(cin200,password);
if (c!=-1){

if(strcmp(compte,"adherent")==0){
rolx=6;
}
else if(strcmp(compte,"admin")==0){
rolx=1;
}
else if(strcmp(compte,"coach")==0){
rolx=5;
}
else if(strcmp(compte,"dietecien")==0){
rolx=4;
}
else if(strcmp(compte,"kine")==0){
rolx=3;
}
else if(strcmp(compte,"medecin")==0){
rolx=2;
}


if(rolx==6){
b=modifier_adherent (cin,password2,rolx,nom,prenom,mail,specialite,telephone,ddj,ddm,dda,dfj,dfm, dfa,dnj,dnm,dna);
}
else if (rolx!=6){
n=modifier_staff_coach (cin,password2,nom, prenom,mail,compte,specialite,telephone,dnj,dnm,dna);
}
gtk_label_set_text(GTK_LABEL(expl),"modifier faite");
}
else if (c==-1){
gtk_label_set_text(GTK_LABEL(expl),"!!!!!!!!!!!!!!!!! mot de pass erronee");
}

}

GtkWidget *medecin;

void
on_medecin_set_focus                   (GtkWidget      *objet_graphique,
                                        GtkWidget       *widget,
                                        gpointer         user_data)
{

GtkWidget *treeview2;
GtkWidget *medecin;
GtkWidget *medecin410;
GtkWidget *medecin411;
GtkWidget *medecin412;
GtkWidget *medecin413;
GtkWidget *medecin414;
GtkWidget *medecin415;
GtkWidget *medecin416;
char date[30],prenom[30],mail[30],username[30],telephone[30],login[30],abonnement[30];


FILE *f,*g;
int role;
char password[30];
long cin23;
char username20[30];
char cin20[30];
char prenom20[30];
char password20[30];
char date20[30];
char date21[30];
char mail20[30];
char compt20[30];
char abonnement20[30];
char telephone20[30];
long telephone21;

int ddj20,dda20,ddm20,dfa20,dfm20,dfj20,rolx20,dna20,dnm20,dnj20,m;

printf("\n %s \nfffffffffffffffffffff",login);

medecin=lookup_widget(objet_graphique,"medecin");

medecin410=lookup_widget(objet_graphique,"label829");
medecin411=lookup_widget(objet_graphique,"label830");
medecin412=lookup_widget(objet_graphique,"label831");

medecin413=lookup_widget(objet_graphique,"label832");
medecin414=lookup_widget(objet_graphique,"label833");
medecin415=lookup_widget(objet_graphique,"label834");

//medecin416=lookup_widget(objet_graphique,"label593");


g=fopen("/home/jasser/Desktop/MyGym/gym/src/logs.txt","r");
if(g!=NULL){
printf("pos99999999999966666669999\n");
while(fscanf(g,"%s %d",login,&m)!=EOF){

printf("ffffffff\n %s \n",login);
}
}

f=fopen("/home/jasser/Desktop/MyGym/gym/src/info_staff_coach","r");
if(f!=NULL){
printf("pos999999999999********************9999\n");
while(fscanf(f,"%ld %s %s %s %s %s %s %ld %d %d %d ",&cin23,password20,username20,prenom20,mail20,compt20,abonnement20,&telephone21,&dnj20,&dnm20,&dna20)!=EOF)
{
	
	sprintf(cin20,"%ld",cin23);
if(strcmp(login,cin20)==0)
{
printf("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz55555555555555z");
	sprintf(date20,"%d/%d/%d",dnj20,dnm20,dna20);
	
	sprintf(telephone20,"%ld",telephone21);

strcpy(username,username20);
strcpy(prenom,prenom20);
strcpy(mail,mail20);
strcpy(abonnement,abonnement20);
strcpy(telephone,telephone20);
strcpy(date,date20);
gtk_label_set_text(GTK_LABEL(medecin410),username);
gtk_label_set_text(GTK_LABEL(medecin411),prenom);
gtk_label_set_text(GTK_LABEL(medecin412),login);
gtk_label_set_text(GTK_LABEL(medecin413),mail);
gtk_label_set_text(GTK_LABEL(medecin414),telephone);
gtk_label_set_text(GTK_LABEL(medecin415),date);
}

}

}
fclose(f);


treeview2=lookup_widget(medecin,"treeview10");


afficher_adherent(treeview2);



}

GtkWidget *coach;

void
on_coach_set_focus                     (GtkWidget      *objet_graphique,
                                        GtkWidget       *widget,
                                        gpointer         user_data)
{

GtkWidget *treeview2;
GtkWidget *coach;


GtkWidget *coach410;
GtkWidget *coach411;
GtkWidget *coach412;
GtkWidget *coach413;
GtkWidget *coach414;
GtkWidget *coach415;
GtkWidget *coach416;
char date[30],prenom[30],mail[30],username[30],telephone[30],login[30],abonnement[30];


FILE *f,*g;
int role;
char password[30];
long cin23;
char username20[30];
char cin20[30];
char prenom20[30];
char password20[30];
char date20[30];
char date21[30];
char mail20[30];
char compt20[30];
char abonnement20[30];
char telephone20[30];
long telephone21;

int ddj20,dda20,ddm20,dfa20,dfm20,dfj20,rolx20,dna20,dnm20,dnj20,m;

printf("\n %s \nfffffffffffffffffffff",login);

coach=lookup_widget(objet_graphique,"coach");

coach410=lookup_widget(objet_graphique,"label616");
coach411=lookup_widget(objet_graphique,"label617");
coach412=lookup_widget(objet_graphique,"label618");

coach413=lookup_widget(objet_graphique,"label619");
coach414=lookup_widget(objet_graphique,"label620");
coach415=lookup_widget(objet_graphique,"label621");

coach416=lookup_widget(objet_graphique,"label622");


g=fopen("/home/jasser/Desktop/MyGym/gym/src/logs.txt","r");
if(g!=NULL)
{
printf("pos99999999999966666669999\n");
while(fscanf(g,"%s %d",login,&m)!=EOF){

printf("ffffffff\n %s \n",login);
}
}

f=fopen("/home/jasser/Desktop/MyGym/gym/src/info_staff_coach","r");
if(f!=NULL)
{
printf("pos999999999999********************9999\n");
while(fscanf(f,"%ld %s %s %s %s %s %s %ld %d %d %d ",&cin23,password20,username20,prenom20,mail20,compt20,abonnement20,&telephone21,&dnj20,&dnm20,&dna20)!=EOF)
{	
	sprintf(cin20,"%ld",cin23);
if(strcmp(login,cin20)==0)
{
printf("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz55555555555555z");
	sprintf(date20,"%d/%d/%d",dnj20,dnm20,dna20);
	sprintf(telephone20,"%ld",telephone21);

strcpy(username,username20);
strcpy(prenom,prenom20);
strcpy(mail,mail20);
strcpy(abonnement,abonnement20);
strcpy(telephone,telephone20);
strcpy(date,date20);
gtk_label_set_text(GTK_LABEL(coach410),username);
gtk_label_set_text(GTK_LABEL(coach411),prenom);
gtk_label_set_text(GTK_LABEL(coach412),login);
gtk_label_set_text(GTK_LABEL(coach413),mail);
gtk_label_set_text(GTK_LABEL(coach414),telephone);
gtk_label_set_text(GTK_LABEL(coach415),date);
gtk_label_set_text(GTK_LABEL(coach416),abonnement);
}

}

}
fclose(f);


treeview2=lookup_widget(coach,"treeview6");


afficher_adherent(treeview2);





}

GtkWidget *dietecien;
void
on_dietecien_set_focus                 (GtkWidget      *objet_graphique,
                                        GtkWidget       *widget,
                                        gpointer         user_data)
{
GtkWidget *treeview2;
GtkWidget *dietecien;
GtkWidget *dietecien410;
GtkWidget *dietecien411;
GtkWidget *dietecien412;
GtkWidget *dietecien413;
GtkWidget *dietecien414;
GtkWidget *dietecien415;
GtkWidget *dietecien416;
char date[30],prenom[30],mail[30],username[30],telephone[30],login[30],abonnement[30];


FILE *f,*g;
int role;
char password[30];
long cin23;
char username20[30];
char cin20[30];
char prenom20[30];
char password20[30];
char date20[30];
char date21[30];
char mail20[30];
char compt20[30];
char abonnement20[30];
char telephone20[30];
long telephone21;

int ddj20,dda20,ddm20,dfa20,dfm20,dfj20,rolx20,dna20,dnm20,dnj20,m;

printf("\n %s \nfffffffffffffffffffff",login);

dietecien=lookup_widget(objet_graphique,"dietecien");

dietecien410=lookup_widget(objet_graphique,"labe767");
dietecien411=lookup_widget(objet_graphique,"label768");
dietecien412=lookup_widget(objet_graphique,"label769");

dietecien413=lookup_widget(objet_graphique,"label770");
dietecien414=lookup_widget(objet_graphique,"label771");
dietecien415=lookup_widget(objet_graphique,"label772");
dietecien416=lookup_widget(objet_graphique,"label773");


g=fopen("/home/jasser/Desktop/MyGym/gym/src/logs.txt","r");
if(g!=NULL){
printf("pos99999999999966666669999\n");
while(fscanf(g,"%s %d",login,&m)!=EOF){

printf("ffffffff\n %s \n",login);
}
}

f=fopen("/home/jasser/Desktop/MyGym/gym/src/info_staff_coach","r");
if(f!=NULL){
printf("pos999999999999********************9999\n");
while(fscanf(f,"%ld %s %s %s %s %s %s %ld %d %d %d ",&cin23,password20,&rolx20,username20,prenom20,mail20,compt20,abonnement20,&telephone21,&dnj20,&dnm20,&dna20)!=EOF)
{
	
	sprintf(cin20,"%ld",cin23);
if(strcmp(login,cin20)==0)
{
printf("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz55555555555555z");
	sprintf(date20,"%d/%d/%d",dnj20,dnm20,dna20);
	sprintf(telephone20,"%ld",telephone21);

strcpy(username,username20);
strcpy(prenom,prenom20);
strcpy(mail,mail20);
strcpy(abonnement,abonnement20);
strcpy(telephone,telephone20);
strcpy(date,date20);
gtk_label_set_text(GTK_LABEL(dietecien410),username);
gtk_label_set_text(GTK_LABEL(dietecien411),prenom);
gtk_label_set_text(GTK_LABEL(dietecien412),login);
gtk_label_set_text(GTK_LABEL(dietecien413),mail);
gtk_label_set_text(GTK_LABEL(dietecien414),telephone);
gtk_label_set_text(GTK_LABEL(dietecien415),date);
gtk_label_set_text(GTK_LABEL(dietecien416),abonnement);
}

}

}
fclose(f);
dietecien=lookup_widget(objet_graphique,"dietecien");

treeview2=lookup_widget(dietecien,"treeview7");


afficher_adherent(treeview2);

}

GtkWidget *kine;
void
on_kine_set_focus                      (GtkWidget      *objet_graphique,
                                        GtkWidget       *widget,
                                        gpointer         user_data)
{
GtkWidget *treeview2;

GtkWidget *kine410;
GtkWidget *kine411;
GtkWidget *kine412;
GtkWidget *kine413;
GtkWidget *kine414;
GtkWidget *kine415;
GtkWidget *kine416;
char date[30],prenom[30],mail[30],username[30],telephone[30],login[30],abonnement[30];


FILE *f,*g;
int role;
char password[30];
long cin23;
char username20[30];
char cin20[30];
char prenom20[30];
char password20[30];
char date20[30];
char date21[30];
char mail20[30];
char compt20[30];
char abonnement20[30];
char telephone20[30];
long telephone21;

int ddj20,dda20,ddm20,dfa20,dfm20,dfj20,rolx20,dna20,dnm20,dnj20,m;

printf("\n %s \nfffffffffffffffffffff",login);

dietecien=lookup_widget(objet_graphique,"dietecien");

kine410=lookup_widget(objet_graphique,"label782");
kine411=lookup_widget(objet_graphique,"label783");
kine412=lookup_widget(objet_graphique,"label784");
kine413=lookup_widget(objet_graphique,"label785");
kine414=lookup_widget(objet_graphique,"label786");
kine415=lookup_widget(objet_graphique,"label787");
kine416=lookup_widget(objet_graphique,"label788");


g=fopen("/home/jasser/Desktop/MyGym/gym/src/logs.txt","r");
if(g!=NULL){
printf("pos99999999999966666669999\n");
while(fscanf(g,"%s %d",login,&m)!=EOF){

printf("ffffffff\n %s \n",login);
}
}

f=fopen("/home/jasser/Desktop/MyGym/gym/src/info_staff_coach","r");
if(f!=NULL){
printf("pos999999999999********************9999\n");
while(fscanf(f,"%ld %s %s %s %s %s %s %ld %d %d %d ",&cin23,password20,&rolx20,username20,prenom20,mail20,compt20,abonnement20,&telephone21,&dnj20,&dnm20,&dna20)!=EOF)
{
	
	sprintf(cin20,"%ld",cin23);
if(strcmp(login,cin20)==0)
{
printf("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz55555555555555z");
	sprintf(date20,"%d/%d/%d",dnj20,dnm20,dna20);
	sprintf(telephone20,"%ld",telephone21);

strcpy(username,username20);
strcpy(prenom,prenom20);
strcpy(mail,mail20);
strcpy(abonnement,abonnement20);
strcpy(telephone,telephone20);
strcpy(date,date20);
gtk_label_set_text(GTK_LABEL(kine410),username);
gtk_label_set_text(GTK_LABEL(kine411),prenom);
gtk_label_set_text(GTK_LABEL(kine412),login);
gtk_label_set_text(GTK_LABEL(kine413),mail);
gtk_label_set_text(GTK_LABEL(kine414),telephone);
gtk_label_set_text(GTK_LABEL(kine415),date);
gtk_label_set_text(GTK_LABEL(kine416),abonnement);
}

}

}
fclose(f);


treeview2=lookup_widget(kine,"treeview8");


afficher_adherent(treeview2);

}


void
on_valider_nouveau_compt_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}

GtkWidget *admin;
void
on_supprimer_as_admin_staff_clicked    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *supprimeraz;
int cin;
admin=lookup_widget(objet_graphique,"admin");
supprimeraz=lookup_widget(objet_graphique,"spinbutton26");
cin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(supprimeraz));
supprimer_sc(cin);
}

GtkWidget *fiche_medicale_adherants;
void
on_button35_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{



GtkWidget *nom,*prenom,*taille,*poids,*cin,*antecidant;

long cin2;
int poids1,taille1;
char username1[30];
char prenom1[30];
char nom1[30];
char antecedent[30];


fiche_medicale_adherants=lookup_widget(objet_graphique,"fiche_medicale_adherants");

nom=lookup_widget(objet_graphique,"entry149");
prenom=lookup_widget(objet_graphique,"entry150");
antecidant=lookup_widget(objet_graphique,"entry151");

cin=lookup_widget(objet_graphique,"spinbutton69");
taille=lookup_widget(objet_graphique,"spinbutton70");
poids=lookup_widget(objet_graphique,"spinbutton71");


strcpy(nom1,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(prenom1,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(antecedent,gtk_entry_get_text(GTK_ENTRY(antecidant)));

cin2=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cin));
poids1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(poids));
taille1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(taille));

creer_fiche_medicale(&cin2,nom1,prenom1,&taille1,&poids1,antecedent);




}

GtkWidget *fiche,*medecin;
void
on_button37_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *cin10;

medecin=lookup_widget(objet_graphique,"medecin");
fiche=create_fiche();
gtk_widget_show(fiche);
char cin[30];
long cin1;
cin10=lookup_widget(objet_graphique,"spinbutton72");
cin1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(cin10));
sprintf(cin,"%ld",cin1);
memcin(cin);
printf("posssssssssssssddddddddddddddddddddddddd %s\n",cin);
}


void
on_button40_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}

GtkWidget *fiche;
void
on_fiche_set_focus                     (GtkWidget      *objet_graphique,
                                        GtkWidget       *widget,
                                        gpointer         user_data)
{
GtkWidget *cin10,*kine410,*kine411,*kine412,*kine413,*kine414,*kine415;
FILE *f,*g;
long cin;

char nom[30],prenom[30],antecedant[30],taille1[30],poids1[30],imc1[30],cin1[30],cin2[30];
char nom3[30],prenom3[30],antecedant3[30],taille3[30],poids3[30],imc3[30];
int taille,poids;
float imc;
fiche=lookup_widget(objet_graphique,"fiche");

g=fopen("/home/jasser/Desktop/MyGym/gym/src/memc.txt","r");
if(g!=NULL){
printf("pos99999999999966666669999\n");
while(fscanf(g,"%s",cin1)!=EOF){

}
}

kine410=lookup_widget(objet_graphique,"label821");
kine411=lookup_widget(objet_graphique,"label822");
kine412=lookup_widget(objet_graphique,"label823");
kine413=lookup_widget(objet_graphique,"label824");
kine414=lookup_widget(objet_graphique,"label825");
kine415=lookup_widget(objet_graphique,"label826");




f=fopen("/home/jasser/Desktop/MyGym/gym/src/fiche_medicale.txt","r");
if(f!=NULL)
{
printf("pos999999999999********************9999 %s\n",cin1);
while(fscanf(f,"%ld %s %s %d %d %f %s \n",&cin,nom,prenom,&taille,&poids,&imc,antecedant)!=EOF)
{
	
sprintf(cin2,"%ld",cin);
if(strcmp(cin2,cin1)==0)
{
	sprintf(taille1,"%d",taille);
	sprintf(poids1,"%d",poids);
	sprintf(imc1,"%f",imc);
strcpy(nom3,nom);
strcpy(prenom3,prenom);
strcpy(antecedant3,antecedant);
printf("nom%s\nprenom3%s\ntaille1%s\npoids1%s\nimc1%s\nantecedant3%s\n",nom3,prenom3,taille1,poids1,imc1,antecedant3);

}

}

}
fclose(f);
gtk_label_set_text(GTK_LABEL(kine410),nom3);
gtk_label_set_text(GTK_LABEL(kine411),prenom3);
gtk_label_set_text(GTK_LABEL(kine412),taille1);
gtk_label_set_text(GTK_LABEL(kine413),poids1);
gtk_label_set_text(GTK_LABEL(kine414),imc1);
gtk_label_set_text(GTK_LABEL(kine415),antecedant3);

}


void
on_button45_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button44_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button47_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button46_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button42_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button43_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}

GtkWidget *admin;
void
on_modifier_as_adm_coach_staff_clicked (GtkWidget         *objet_graphique,
                                        gpointer         user_data)
{



GtkWidget *output410;
GtkWidget *output411;
GtkWidget *output412;
GtkWidget *output413;
char mail[30],abonnement[30];
long cin,telephone;

FILE *f;
long cin5;
char username5[30];
char password5[30];
char prenom5[30];
char nom5[30];
char mail5[30];
char compt5[30];
char abonnement5[30];
long telephone5;
int ddj5,dda5,ddm5,dfa5,dfm5,dfj5,dna5,dnm5,dnj5,m=0,rolx5;

char username1[30];
char password1[30];
char prenom1[30];
char nom1[30];
char mail1[30];
char compt1[30];
char abonnement1[30];
long telephone1;
int ddj1,dda1,ddm1,dfa1,dfm1,dfj1,dna1,dnm1,dnj1,rolx1;

admin=lookup_widget(objet_graphique,"admin");
output410=lookup_widget(objet_graphique,"spinbutton26");
output411=lookup_widget(objet_graphique,"spinbutton78");


output412=lookup_widget(objet_graphique,"entry154");


cin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output410));
telephone=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output411));


strcpy(mail,gtk_entry_get_text(GTK_ENTRY(output412)));

f=fopen("/home/jasser/Desktop/MyGym/gym/src/info_staff_coach","r");
if(f!=NULL){
while(fscanf(f,"%ld %s %s %s %s %s %s %ld %d %d %d ",&cin5,password5,username5,prenom5,mail5,compt5,abonnement5,&telephone5,&dnj5,&dnm5,&dna5)!=EOF)
{
if(cin==cin5){
dna1=dna5;
dnm1=dnm5;
dnj1=dnj5;

strcpy(compt1,compt5);
strcpy(prenom1,prenom5);
strcpy(username1,username5);
strcpy(password1,password5);
strcpy(abonnement1,abonnement5);

}
}
}
fclose(f);
supprimer_sc(cin);
ajouter_staff_coach(cin,password1,prenom1,username1,mail,abonnement1,compt1,telephone,dnj1,dnm1,dna1);


}


void
on_button36_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


GtkWidget *adherent;

void
on_button49_clicked                    (GtkWidget         *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *output410;
GtkWidget *output411;
GtkWidget *output412;
GtkWidget *output413;
char mail[30],abonnement[30];
long cin,telephone;

FILE *f;
long cin5;
char username5[30];
char password5[30];
char prenom5[30];
char nom5[30];
char mail5[30];
char compt5[30];
char abonnement5[30];
long telephone5;
int ddj5,dda5,ddm5,dfa5,dfm5,dfj5,dna5,dnm5,dnj5,m=0,rolx5;

char username1[30];
char password1[30];
char prenom1[30];
char nom1[30];
char mail1[30];
char compt1[30];
char abonnement1[30];
long telephone1;
int ddj1,dda1,ddm1,dfa1,dfm1,dfj1,dna1,dnm1,dnj1,rolx1;

adherent=lookup_widget(objet_graphique,"adherent");
output410=lookup_widget(objet_graphique,"spinbutton88");
output411=lookup_widget(objet_graphique,"spinbutton89");


output412=lookup_widget(objet_graphique,"entry175");
output413=lookup_widget(objet_graphique,"entry172");

cin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output410));
telephone=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output411));


strcpy(mail,gtk_entry_get_text(GTK_ENTRY(output412)));
strcpy(password1,gtk_entry_get_text(GTK_ENTRY(output413)));
f=fopen("/home/jasser/Desktop/MyGym/gym/src/info_users.txt","r");
if(f!=NULL){
while(fscanf(f,"%ld %s %d %s %s %s %s %ld %d %d %d %d %d %d %d %d %d ",&cin5, password5,&rolx5,username5,mail5, prenom5,abonnement5,&telephone5,&ddj5,&ddm5,&dda5,&dfj5,&dfm5,&dfa5,&dnj5,&dnm5,&dna5)!=EOF)
{
if(cin==cin5){
dna1=dna5;
dnm1=dnm5;
dnj1=dnj5;

dfa1=dfa5;
dfm1=dfm5;
dfj1=dfj5;

dda1=dda5;
ddm1=ddm5;
ddj1=ddj5;

strcpy(prenom1,prenom5);
strcpy(username1,username5);
rolx1=rolx5;
strcpy(abonnement1,abonnement5);

}
}
}
fclose(f);
supprimer(cin);
ajouter(cin,password1,rolx1,prenom1,username1,mail,abonnement1,telephone,ddj1,ddm1,dda1,dfj1,dfm1,dfa1,dnj1,dnm1,dna1);

}

GtkWidget *kine;
void
on_button55_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


GtkWidget *output410;
GtkWidget *output411;
GtkWidget *output412;
GtkWidget *output413;
char mail[30],abonnement[30];
long cin,telephone;

FILE *f;
long cin5;
char username5[30];
char password5[30];
char prenom5[30];
char nom5[30];
char mail5[30];
char compt5[30];
char abonnement5[30];
long telephone5;
int ddj5,dda5,ddm5,dfa5,dfm5,dfj5,dna5,dnm5,dnj5,m=0,rolx5;

char username1[30];
char password1[30];
char prenom1[30];
char nom1[30];
char mail1[30];
char compt1[30];
char abonnement1[30];
long telephone1;
int ddj1,dda1,ddm1,dfa1,dfm1,dfj1,dna1,dnm1,dnj1,rolx1;

kine=lookup_widget(objet_graphique,"kine");
output410=lookup_widget(objet_graphique,"spinbutton90");
output411=lookup_widget(objet_graphique,"spinbutton91");


output412=lookup_widget(objet_graphique,"entry171");
output413=lookup_widget(objet_graphique,"entry168");


cin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output410));
telephone=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output411));


strcpy(mail,gtk_entry_get_text(GTK_ENTRY(output412)));
strcpy(password1,gtk_entry_get_text(GTK_ENTRY(output413)));

f=fopen("/home/jasser/Desktop/MyGym/gym/src/info_staff_coach","r");
if(f!=NULL){
while(fscanf(f,"%ld %s %s %s %s %s %s %ld %d %d %d ",&cin5,password5,username5,prenom5,mail5,compt5,abonnement5,&telephone5,&dnj5,&dnm5,&dna5)!=EOF)
{
if(cin==cin5){
dna1=dna5;
dnm1=dnm5;
dnj1=dnj5;

strcpy(compt1,compt5);
strcpy(prenom1,prenom5);
strcpy(username1,username5);
strcpy(abonnement1,abonnement5);

}
}
}
fclose(f);
supprimer_sc(cin);
ajouter_staff_coach(cin,password1,prenom1,username1,mail,abonnement1,compt1,telephone,dnj1,dnm1,dna1);




}

GtkWidget *dietecien;
void
on_button53_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *output410;
GtkWidget *output411;
GtkWidget *output412;
GtkWidget *output413;
char mail[30],abonnement[30];
long cin,telephone;

FILE *f;
long cin5;
char username5[30];
char password5[30];
char prenom5[30];
char nom5[30];
char mail5[30];
char compt5[30];
char abonnement5[30];
long telephone5;
int ddj5,dda5,ddm5,dfa5,dfm5,dfj5,dna5,dnm5,dnj5,m=0,rolx5;

char username1[30];
char password1[30];
char prenom1[30];
char nom1[30];
char mail1[30];
char compt1[30];
char abonnement1[30];
long telephone1;
int ddj1,dda1,ddm1,dfa1,dfm1,dfj1,dna1,dnm1,dnj1,rolx1;

dietecien=lookup_widget(objet_graphique,"dietecien");
output410=lookup_widget(objet_graphique,"spinbutton92");
output411=lookup_widget(objet_graphique,"spinbutton93");


output412=lookup_widget(objet_graphique,"entry167");
output413=lookup_widget(objet_graphique,"entry164");


cin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output410));
telephone=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output411));


strcpy(mail,gtk_entry_get_text(GTK_ENTRY(output412)));
strcpy(password1,gtk_entry_get_text(GTK_ENTRY(output413)));

f=fopen("/home/jasser/Desktop/MyGym/gym/src/info_staff_coach","r");
if(f!=NULL){
while(fscanf(f,"%ld %s %s %s %s %s %s %ld %d %d %d ",&cin5,password5,username5,prenom5,mail5,compt5,abonnement5,&telephone5,&dnj5,&dnm5,&dna5)!=EOF)
{
if(cin==cin5){
dna1=dna5;
dnm1=dnm5;
dnj1=dnj5;

strcpy(compt1,compt5);
strcpy(prenom1,prenom5);
strcpy(username1,username5);
strcpy(abonnement1,abonnement5);

}
}
}
fclose(f);
supprimer_sc(cin);
ajouter_staff_coach(cin,password1,prenom1,username1,mail,abonnement1,compt1,telephone,dnj1,dnm1,dna1);



}

GtkWidget *medecin;
void
on_button58_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *output410;
GtkWidget *output411;
GtkWidget *output412;
GtkWidget *output413;
char mail[30],abonnement[30];
long cin,telephone;

FILE *f;
long cin5;
char username5[30];
char password5[30];
char prenom5[30];
char nom5[30];
char mail5[30];
char compt5[30];
char abonnement5[30];
long telephone5;
int ddj5,dda5,ddm5,dfa5,dfm5,dfj5,dna5,dnm5,dnj5,m=0,rolx5;

char username1[30];
char password1[30];
char prenom1[30];
char nom1[30];
char mail1[30];
char compt1[30];
char abonnement1[30];
long telephone1;
int ddj1,dda1,ddm1,dfa1,dfm1,dfj1,dna1,dnm1,dnj1,rolx1;

medecin=lookup_widget(objet_graphique,"medecin");
output410=lookup_widget(objet_graphique,"spinbutton94");
output411=lookup_widget(objet_graphique,"spinbutton95");


output412=lookup_widget(objet_graphique,"entry132");
output413=lookup_widget(objet_graphique,"entry128");


cin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output410));
telephone=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output411));


strcpy(mail,gtk_entry_get_text(GTK_ENTRY(output412)));
strcpy(password1,gtk_entry_get_text(GTK_ENTRY(output413)));

f=fopen("/home/jasser/Desktop/MyGym/gym/src/info_staff_coach","r");
if(f!=NULL){
while(fscanf(f,"%ld %s %s %s %s %s %s %ld %d %d %d ",&cin5,password5,username5,prenom5,mail5,compt5,abonnement5,&telephone5,&dnj5,&dnm5,&dna5)!=EOF)
{
if(cin==cin5){
dna1=dna5;
dnm1=dnm5;
dnj1=dnj5;

strcpy(compt1,compt5);
strcpy(prenom1,prenom5);
strcpy(username1,username5);
strcpy(abonnement1,abonnement5);

}
}
}
fclose(f);
supprimer_sc(cin);
ajouter_staff_coach(cin,password1,prenom1,username1,mail,abonnement1,compt1,telephone,dnj1,dnm1,dna1);


}

GtkWidget *coach;
void
on_button51_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *output410;
GtkWidget *output411;
GtkWidget *output412;
GtkWidget *output413;
char mail[30],abonnement[30];
long cin,telephone;

FILE *f;
long cin5;
char username5[30];
char password5[30];
char prenom5[30];
char nom5[30];
char mail5[30];
char compt5[30];
char abonnement5[30];
long telephone5;
int ddj5,dda5,ddm5,dfa5,dfm5,dfj5,dna5,dnm5,dnj5,m=0,rolx5;

char username1[30];
char password1[30];
char prenom1[30];
char nom1[30];
char mail1[30];
char compt1[30];
char abonnement1[30];
long telephone1;
int ddj1,dda1,ddm1,dfa1,dfm1,dfj1,dna1,dnm1,dnj1,rolx1;

coach=lookup_widget(objet_graphique,"coach");
output410=lookup_widget(objet_graphique,"spinbutton96");
output411=lookup_widget(objet_graphique,"spinbutton97");


output412=lookup_widget(objet_graphique,"entry162");
output413=lookup_widget(objet_graphique,"entry159");


cin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output410));
telephone=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(output411));


strcpy(mail,gtk_entry_get_text(GTK_ENTRY(output412)));
strcpy(password1,gtk_entry_get_text(GTK_ENTRY(output413)));

f=fopen("/home/jasser/Desktop/MyGym/gym/src/info_staff_coach","r");
if(f!=NULL){
while(fscanf(f,"%ld %s %s %s %s %s %s %ld %d %d %d ",&cin5,password5,username5,prenom5,mail5,compt5,abonnement5,&telephone5,&dnj5,&dnm5,&dna5)!=EOF)
{
if(cin==cin5){
dna1=dna5;
dnm1=dnm5;
dnj1=dnj5;

strcpy(compt1,compt5);
strcpy(prenom1,prenom5);
strcpy(username1,username5);
strcpy(abonnement1,abonnement5);

}
}
}
fclose(f);
supprimer_sc(cin);
ajouter_staff_coach(cin,password1,prenom1,username1,mail,abonnement1,compt1,telephone,dnj1,dnm1,dna1);

}


void
on_button59_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_widget_show(authentification);
gtk_widget_hide(medecin);
}


void
on_button60_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_widget_destroy(home);
gtk_widget_show(authentification);
gtk_widget_hide(adherent);
}


void
on_button61_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_widget_destroy(home);
gtk_widget_show(authentification);
gtk_widget_hide(admin);
}

