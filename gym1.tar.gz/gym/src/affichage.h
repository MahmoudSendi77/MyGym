
#include <gtk/gtk.h>
void afficher_staf_coach(GtkWidget *liste);
