#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include"verifier.h"
int verifier(char login[],char password[])
{FILE *f;
int role,a=1,b=1,c=-1;
char login1[20];
char password1[20];
f=fopen("/home/jasser/Desktop/MyGym/gym/src/login.txt","r");
if (f!=NULL)
{
while(fscanf(f,"%s %s %d",login1, password1,&role)!=EOF)
{
a=strcmp(login,login1);
   b=strcmp(password,password1);
if (a==0 && b==0)
     c =role;
}
}
fclose(f);
return c;
}

void valider_compts(char login[],char password[],int role)
{
FILE *f;
f=fopen("/home/jasser/Desktop/MyGym/gym/src/login.txt","a");
if(f!=NULL)
{fprintf(f,"%s %s %d \n",login,password,role);
fclose(f);
}
}



void creer_fiche_medicale(long *cin , char nom[], char prenom[],int *taille,int *poids,char antecedant[])
{
float imc,c;
int a,b;
a=*poids;
b=(*taille)/100;
c=(float)a/b;
imc=c/b;
FILE *f;
f=fopen("/home/jasser/Desktop/MyGym/gym/src/fiche_medicale.txt","a");
if(f!=NULL)
{fprintf(f,"%ld %s %s %d %d %0.2f %s \n",*cin,nom,prenom,*taille,*poids,imc,antecedant);
fclose(f);
}
}

void creer_evennement(long cin ,char nom[], char lieu[], char heure[],int dej,int dem,int dea)
{
FILE *f;
f=fopen("/home/jasser/Desktop/MyGym/gym/src/fiche_evennement.txt","a");
if(f!=NULL)
{fprintf(f,"%ld %s %s %s %d %d %d \n",cin,nom,lieu,heure,dej,dem,dea);
fclose(f);
}


}
void creer_rendez_vous(long cin2,int dej,int dem,int dea, char heure[],long cin)
{
printf("ssssssssssssssssssssssssssssssssssssssssssss\n");
FILE *f;
f=fopen("/home/jasser/Desktop/MyGym/gym/src/rendez_vous.txt","a");
if(f!=NULL)
{fprintf(f,"%ld %d %d %d %s %ld \n",cin2,dej,dem,dea,heure,cin);
fclose(f);
}
}
